function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function updateData() {
  document.getElementById('temp').textContent = getRandomInt(20, 30);
  document.getElementById('hum').textContent = getRandomInt(40, 70);
}

setInterval(updateData, 5000); // Update every 5 seconds

function toggleFan() {
  alert("Fan toggled (simulate command sent to device).");
}