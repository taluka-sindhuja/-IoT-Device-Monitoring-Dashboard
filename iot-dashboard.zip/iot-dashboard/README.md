# IoT Monitoring Dashboard

A simple responsive web dashboard that simulates IoT device data.

## Features
- Displays real-time temperature and humidity (simulated)
- Toggle button to control a device (e.g., fan)
- Responsive design for mobile and desktop

## How to Use
1. Download all files into a folder
2. Open `index.html` in your browser
3. Watch the simulated data update every 5 seconds
4. Click "Toggle Fan" to simulate control

## Future Ideas
- Connect to real sensors via MQTT/WebSocket
- Add live charts with Chart.js
- Store device data in localStorage or Firebase

## License
MIT