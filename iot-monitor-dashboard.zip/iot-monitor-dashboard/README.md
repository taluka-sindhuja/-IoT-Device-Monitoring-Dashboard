# IoT Device Monitoring Dashboard

A responsive and accessible web dashboard to monitor simulated IoT sensor data (temperature and humidity), with a toggleable fan control.

## Features

- Live-updating sensor simulation
- Fan control with simulated backend delay
- Responsive and accessible design
- Pure HTML, CSS, and JavaScript (no dependencies)

## Getting Started

Open `index.html` in your browser.

## License

MIT License
