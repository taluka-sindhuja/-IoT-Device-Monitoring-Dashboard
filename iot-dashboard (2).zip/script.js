// JavaScript to simulate fetching IoT sensor data
function refreshData() {
  const temp = (20 + Math.random() * 10).toFixed(1); // Simulate temperature
  const humidity = (40 + Math.random() * 20).toFixed(1); // Simulate humidity

  document.getElementById("temp").textContent = temp;
  document.getElementById("humidity").textContent = humidity;

  alert("Sensor data refreshed!");
}

// Initial data load
window.onload = refreshData;
